from flask import Flask, request, render_template
import sqlite3
import pickle

app = Flask(__name__)

model = pickle.load(open("model.pkl", "rb"))
vectorizer = pickle.load(open("vectorizer.pkl", "rb"))

def init_db():
    conn = sqlite3.connect("database.db")
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS reports (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            text TEXT,
            prediction TEXT,
            confidence REAL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.commit()
    conn.close()

@app.route("/", methods=["GET", "POST"])
def home():
    prediction = None
    confidence = None

    if request.method == "POST":
        text = request.form["text"]

        transformed = vectorizer.transform([text])
        pred = model.predict(transformed)[0]
        prob = model.predict_proba(transformed).max()

        label = "Fake/Scam" if pred == 1 else "Real/Legit"

        conn = sqlite3.connect("database.db")
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO reports (text, prediction, confidence) VALUES (?, ?, ?)",
            (text, label, float(prob))
        )
        conn.commit()
        conn.close()

        prediction = label
        confidence = round(float(prob) * 100, 2)

    return render_template("index.html", prediction=prediction, confidence=confidence)

if __name__ == "__main__":
    init_db()
    app.run(debug=True)
